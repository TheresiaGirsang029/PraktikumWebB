package com.dicoding.github.main

data class DataUserAPI(
    val items : ArrayList<User>
)
