package com.dicoding.github.main

data class User(
        val login: String,
        val id: Int,
        val avatar_url: String
)
